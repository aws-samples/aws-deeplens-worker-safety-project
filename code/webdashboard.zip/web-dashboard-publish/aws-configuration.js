var awsConfiguration = {
   poolId: '', // 'YourCognitoIdentityPoolId'
   host: '', // 'YourAwsIoTEndpoint', e.g. 'prefix.iot.us-east-1.amazonaws.com'
   region: 'us-east-1'
};
module.exports = awsConfiguration;
