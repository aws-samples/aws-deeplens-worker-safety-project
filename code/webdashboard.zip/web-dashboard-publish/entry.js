var AWS = require('aws-sdk');
var AWSIoTData = require('aws-iot-device-sdk');
var AWSConfiguration = require('./aws-configuration.js');

window.detectedFaces = [];

let urlParams = new URLSearchParams(window.location.search);
let iottopicname = urlParams.get('iottopic');
if (iottopicname) {
  iottopicname = decodeURI(iottopicname)
}

//IoT Subscription Topic
currentlySubscribedTopic = iottopicname;

// Create a client id to use when connecting to AWS IoT.
clientId = 'mqtt-explorer-' + (Math.floor((Math.random() * 100000) + 1));

//AWS.config.credentials = new AWS.Credentials(AWSConfiguration.awsAccessKeyId, AWSConfiguration.awsSecretAccessKey);

// Initialize our configuration.
AWS.config.region = AWSConfiguration.region;

AWS.config.credentials = new AWS.CognitoIdentityCredentials({
   IdentityPoolId: AWSConfiguration.poolId
});

window.iot = AWSIoTData;

// Create the AWS IoT device object.
window.mqttClient = AWSIoTData.device({
   region: AWS.config.region,
   host:AWSConfiguration.host,

   // Use the clientId created earlier.
   clientId: clientId,
   // Connect via secure WebSocket
   protocol: 'wss',
   maximumReconnectTimeMs: 8000,
   debug: true,
   // IMPORTANT: the AWS access key ID, secret key, and sesion token must be
   // initialized with empty strings.
   accessKeyId: '',
   secretKey: '',
   sessionToken: ''
});

// Attempt to authenticate to the Cognito Identity Pool.  Note that this
// example only supports use of a pool which allows unauthenticated
// identities.
var cognitoIdentity = new AWS.CognitoIdentity();
AWS.config.credentials.get(function(err, data) {
   if (!err) {
      console.log('retrieved identity: ' + AWS.config.credentials.identityId);
      var params = {
         IdentityId: AWS.config.credentials.identityId
      };
      cognitoIdentity.getCredentialsForIdentity(params, function(err, data) {
         if (!err) {
            // Update our latest AWS credentials; the MQTT client will use these
            // during its next reconnect attempt.
            mqttClient.updateWebSocketCredentials(data.Credentials.AccessKeyId,
               data.Credentials.SecretKey,
               data.Credentials.SessionToken);
         } else {
            console.log('error retrieving credentials: ' + err);
            alert('error retrieving credentials: ' + err);
         }
      });
   } else {
      console.log('error retrieving identity:' + err);
      alert('error retrieving identity: ' + err);
   }
});

// Connect handler
window.mqttClientConnectHandler = function() {
   document.getElementById("connecting-div").innerHTML = 'Connected to AWS IoT.';
   document.getElementById('message-div').innerHTML = '';

   // Subscribe to our current topic.
   mqttClient.subscribe(currentlySubscribedTopic);
};

// Reconnect handler; update div visibility.
window.mqttClientReconnectHandler = function() {
   console.log('reconnect');
   document.getElementById("connecting-div").style.visibility = 'visible';
};

// Utility function to determine if a value has been defined.
window.isUndefined = function(value) {
   return typeof value === 'undefined' || value === null;
};

function findObjectByKey(array, key, value) {
    for (var i = 0; i < array.length; i++) {
        if (array[i][key] === value) {
            return i;
        }
    }
    return -1;
}

function renderImage(imageSource, boundingBoxes) {

  var canvas = document.getElementById('myCanvas');
  var context = canvas.getContext('2d');

  var imageObj = new Image();

  imageObj.onload = function() {
    scaleFactor = 1
    maxWidth = 1200

    if (imageObj.width > maxWidth) {
      pc = 0.9
      while (pc > 0.1) {
        if (imageObj.width * pc < maxWidth) {
          scaleFactor = pc
          break;
        }
        pc -= 0.1;
      }
    }

    canvas.width = imageObj.width * scaleFactor;
    canvas.height = imageObj.height * scaleFactor;

    context.drawImage(imageObj, 0, 0, imageObj.width * scaleFactor, imageObj.height * scaleFactor);

    if (boundingBoxes) {
      for (bb in boundingBoxes) {
        boundingBox = boundingBoxes[bb]
        context.beginPath();
        context.rect(boundingBox.Left * imageObj.width * scaleFactor, boundingBox.Top * imageObj.height * scaleFactor, imageObj.width * scaleFactor * boundingBox.Width, imageObj.height * scaleFactor * boundingBox.Height);
        if (boundingBox.BoxColor == '#007a99')
          context.lineWidth = 2;
        else if (boundingBox.BoxColor == '#ff8000')
          context.lineWidth = 2;
        else
          context.lineWidth = 2;
        context.strokeStyle = boundingBox.BoxColor;
        context.stroke();
        if (boundingBox.Title) {
          context.font = "9pt Arial";
          context.fillStyle = "#fff";
          //let textheight = context.measureText(boundingBox.Title).height;
          context.fillText(boundingBox.Title, boundingBox.Left * imageObj.width * scaleFactor + 3, boundingBox.Top * imageObj.height * scaleFactor + 15);
        }
      }
    }
  };
  imageObj.src = imageSource
}

// Message handler for lifecycle events
window.mqttClientMessageHandler = function(topic, payload) {

   payloadstr = payload.toString();
   console.log(payloadstr);
   msg = JSON.parse(payloadstr)


     //Print message
  if(msg.Message){
    document.getElementById('message-div').innerHTML = msg.Message.replace(/\n/g, "<br>");
  }

  boxes = []

  if(msg.PersonsWithHat){
      for(pwh in msg.PersonsWithHat){
        bb = msg.PersonsWithHat[pwh].Person.BoundingBox
        bb.BoxColor = "green"
        bb.Title = "Safe"
        boxes.push(bb)
      }
  }

  if(msg.PersonsWithoutHat){
      for(pwh in msg.PersonsWithoutHat){
        bb = msg.PersonsWithoutHat[pwh].BoundingBox
        bb.BoxColor = "red"
        bb.Title = "Unsafe"
        boxes.push(bb)
      }
  }

  renderImage(msg.ImageUrl, boxes)

   //Set scroll bars
   var mc = document.getElementById('messagec');
   mc.scrollTop = mc.scrollHeight;

   //Show Image/Video
   //if(msg.ImageUrl){
  //    document.getElementById('imageDetected').innerHTML = '<img src="' + msg.ImageUrl +  '"></img>';
  //  }
};

// Connect/reconnect event handlers.
mqttClient.on('connect', window.mqttClientConnectHandler);
mqttClient.on('reconnect', window.mqttClientReconnectHandler);
mqttClient.on('message', window.mqttClientMessageHandler);

// Initialize divs.
document.getElementById('connecting-div').style.visibility = 'visible';
document.getElementById('connecting-div').innerHTML = '<p>Connecting to AWS IoT...</p>';


window.publishMessage = window.mqttClient.publisher({
  WebSocket: WebSocket,
  region: AWS.config.region,
  credentials: AWS.config.credentials,
  endpoint: AWSConfiguration.host
})

window.sendMessage = function (){
  var tb = document.getElementById('message');
  if(tb.value){
    alert(tb.value);
    window.publishMessage.send(currentlySubscribedTopic, tb.value);
    tb.value = '';
  }
}
